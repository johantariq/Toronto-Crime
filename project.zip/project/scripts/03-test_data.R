#### Preamble ####
# Purpose: Testing with data
# Author: Johan Tariq
# Date: 23 January 2024
# Contact: johan.tariq@mail.utoronto.ca
# License: MIT
# Pre-requisites: none


#### Workspace setup ####
library(tidyverse)

#### Test data ####
